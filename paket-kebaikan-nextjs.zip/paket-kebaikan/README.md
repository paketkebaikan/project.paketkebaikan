# Paket Kebaikan (Next.js + TypeScript + Tailwind)

## Menjalankan di komputer
    npm install
    npm run dev      # buka http://localhost:3000
    npm run build    # uji build produksi

## Deploy ke Vercel
1. Unggah folder ini ke GitHub, lalu di vercel.com pilih Add New > Project dan impor repositori.
2. Biarkan pengaturan bawaan (Next.js), klik Deploy.
3. Settings > Domains, tambahkan www.paketkebaikan.my.id, ikuti petunjuk DNS dari Vercel.

## Mengubah isi
- Nomor WhatsApp, alamat, link: lib/site.ts (pembagian nomor per layanan: lib/whatsapp.ts)
- Menu kuliner: data/menu.ts | Jadwal umrah: data/jadwal-umrah.ts | Foto galeri: data/gallery.ts
- Artikel: content/artikel/*.md (judul dan ringkasan di data/articles.ts)
- Foto: public/images | Musik: public/audio/bgm.mp3

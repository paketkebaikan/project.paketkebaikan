import type { Config } from 'tailwindcss';
const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  corePlugins: { preflight: false },
  theme: { extend: { colors: { cream: '#EFE8D6', gold: '#E7C982', brand: '#F28C28', cocoa: '#3B2210' } } },
  plugins: [],
};
export default config;

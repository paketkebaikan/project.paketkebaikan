import type { Metadata } from 'next';
import PageHead from '@/components/PageHead';
import ContactForm from '@/components/ContactForm';
import LinkButton from '@/components/LinkButton';
import { SITE } from '@/lib/site';

export const metadata: Metadata = {
  title: 'Kontak',
  description: 'Hubungi Paket Kebaikan lewat WhatsApp untuk pengiriman barang, informasi umrah, dan pesan kuliner. Kantor di Melong, Cimahi Selatan.',
  alternates: { canonical: '/kontak' },
};

export default function KontakPage() {
  return (
    <>
      <PageHead crumb="Kontak" title="Hubungi Paket Kebaikan" lead="Isi formulir singkat, pesan Anda terbuka di WhatsApp siap dikirim." />
      <section className="blk" style={{ paddingTop: 24 }}>
        <div className="wrap grid g2">
          <ContactForm />
          <div className="card">
            <h3>Nomor WhatsApp</h3>
            <p><b>{SITE.kangIman.label}</b><br />{SITE.kangIman.role}<br />{SITE.kangIman.display}</p>
            <p><b>{SITE.tehRisma.label}</b><br />{SITE.tehRisma.role}<br />{SITE.tehRisma.display}</p>
            <h3 style={{ marginTop: 20 }}>Kantor</h3>
            <p style={{ color: 'var(--muted)' }}>{SITE.address}</p>
            <LinkButton href={SITE.maps} external small>Buka di Google Maps</LinkButton>
          </div>
        </div>
      </section>
    </>
  );
}

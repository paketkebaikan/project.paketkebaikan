import type { Metadata } from 'next';
import PageHead from '@/components/PageHead';
import PartnerNote from '@/components/PartnerNote';
import LinkButton from '@/components/LinkButton';
import { SITE } from '@/lib/site';

export const metadata: Metadata = {
  title: 'Tentang Kami',
  description: 'Paket Kebaikan melayani pengiriman barang sejak 2016 dan kini memiliki tiga layanan: ekspedisi, informasi umrah dan haji, serta kuliner UMKM.',
  alternates: { canonical: '/tentang-kami' },
};

export default function TentangKamiPage() {
  return (
    <>
      <PageHead crumb="Tentang Kami" title="Tentang Paket Kebaikan" lead="Dari sebuah niat menyampaikan aneka kebaikan.">
        <p>Paket Kebaikan dimulai pada 2016 dengan layanan pengiriman dokumen, pakaian, makanan, aksesori, barang elektronik, pindahan rumah, hingga sepeda motor ke berbagai wilayah Indonesia.</p>
        <p>Seiring perkembangan usaha, Paket Kebaikan memiliki tiga pilar layanan: Ekspedisi, Umrah &amp; Haji, dan Kuliner. Layanan kuliner merangkul UMKM dan ibu rumah tangga melalui sistem open order.</p>
      </PageHead>
      <section className="blk">
        <div className="wrap">
          <PartnerNote />
          <h2>Kantor</h2>
          <p>{SITE.address}</p>
          <LinkButton href={SITE.maps} external small>Buka di Google Maps</LinkButton>
        </div>
      </section>
    </>
  );
}

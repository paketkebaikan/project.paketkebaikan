import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import './globals.css';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import CTABand from '@/components/CTABand';
import FloatingWhatsApp from '@/components/FloatingWhatsApp';
import MusicPlayer from '@/components/MusicPlayer';
import JsonLd from '@/components/JsonLd';
import { SITE } from '@/lib/site';

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: 'Paket Kebaikan – Pengiriman Barang, Kuliner UMKM, Informasi Umrah', template: '%s | Paket Kebaikan' },
  description: SITE.description,
  keywords: ['Paket Kebaikan', 'jasa pengiriman barang', 'pengiriman motor ke seluruh Indonesia', 'informasi umrah dan haji', 'tips menabung umrah', 'pesan makanan UMKM', 'kuliner rumahan'],
  openGraph: { type: 'website', locale: 'id_ID', siteName: SITE.name, url: SITE.url, images: ['/logo.jpg'] },
};

export const viewport: Viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover' };

const localBusiness = {
  '@context': 'https://schema.org',
  '@type': 'LocalBusiness',
  name: SITE.name,
  url: SITE.url,
  telephone: '+' + SITE.kangIman.number,
  foundingDate: '2016',
  address: {
    '@type': 'PostalAddress',
    streetAddress: 'Melong Green Garden, Jl. Boeing Raya No. 30-32 RT 02 RW 28, Kel. Melong, Kec. Cimahi Selatan',
    addressLocality: 'Cimahi',
    addressRegion: 'Jawa Barat',
    postalCode: '40534',
    addressCountry: 'ID',
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="id">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Poppins:wght@500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body>
        <Header />
        <main>{children}</main>
        <CTABand />
        <Footer />
        <FloatingWhatsApp />
        <MusicPlayer />
        <JsonLd data={localBusiness} />
      </body>
    </html>
  );
}

import type { Metadata } from 'next';
import PageHead from '@/components/PageHead';
import WhatsAppButton from '@/components/WhatsAppButton';
import LinkButton from '@/components/LinkButton';
import Steps from '@/components/Steps';
import { MENU } from '@/data/menu';

export const metadata: Metadata = {
  title: 'Pesan Makanan UMKM, Kuliner Rumahan Open Order',
  description: 'Pesan aneka makanan dari UMKM dan ibu rumah tangga lewat sistem open order. Diantar atau dikirim sesuai jangkauan layanan.',
  alternates: { canonical: '/kuliner' },
};

export default function KulinerPage() {
  return (
    <>
      <PageHead crumb="Kuliner" title="Pesan makanan UMKM, kuliner rumahan" lead="Kolaborasi dengan UMKM dan ibu rumah tangga. Pesan lewat sistem open order, diantar atau dikirim sesuai jangkauan layanan.">
        <div className="cta-row">
          <WhatsAppButton category="kuliner">Pesan via WhatsApp</WhatsAppButton>
          <LinkButton href="/artikel/cara-pesan-kuliner-umkm">Cara pesan</LinkButton>
        </div>
      </PageHead>
      <section className="blk">
        <div className="wrap">
          <h2>Katalog menu</h2>
          <p style={{ color: 'var(--muted)' }}>Menu open order dari Paket Kebaikan. Harga dan jadwal terbaru, tanyakan lewat WhatsApp.</p>
          <div className="grid g3">
            {MENU.map((m) => (
              <div className="card mcard" key={m.slug}>
                <img src={m.img} alt={m.name} loading="lazy" />
                <h3>{m.name}</h3>
                <p style={{ color: 'var(--muted)', fontSize: '.93rem' }}>{m.desc}</p>
                <WhatsAppButton category="kuliner" detail={`Menu: ${m.name}. Jumlah: ...`} small>Pesan menu ini</WhatsAppButton>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="blk alt">
        <div className="wrap">
          <h2>Cara pesan</h2>
          <Steps items={[['Pilih menu', 'Lihat katalog open order.'], ['Chat kami', 'Sebutkan menu dan jumlah.'], ['Konfirmasi', 'Jadwal dan alamat disepakati.'], ['Terima pesanan', 'Diantar atau dikirim.']]} />
        </div>
      </section>
    </>
  );
}

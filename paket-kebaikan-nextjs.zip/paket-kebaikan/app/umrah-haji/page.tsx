import type { Metadata } from 'next';
import Link from 'next/link';
import PageHead from '@/components/PageHead';
import WhatsAppButton from '@/components/WhatsAppButton';
import LinkButton from '@/components/LinkButton';
import Gallery from '@/components/Gallery';
import PartnerNote from '@/components/PartnerNote';
import { UMRAH } from '@/data/gallery';
import { JADWAL } from '@/data/jadwal-umrah';
import { SITE } from '@/lib/site';

export const metadata: Metadata = {
  title: 'Informasi Umrah dan Haji, Tips Menabung Umrah',
  description: 'Informasi program umrah dan haji, jadwal keberangkatan, persiapan ibadah, dan tips menabung. Paket Kebaikan adalah mitra pemasaran Kebaikan Tour.',
  alternates: { canonical: '/umrah-haji' },
};

export default function UmrahHajiPage() {
  return (
    <>
      <PageHead crumb="Umrah & Haji" title="Informasi umrah dan haji" lead="Program, jadwal, persiapan, dan tips menabung untuk perjalanan ke Tanah Suci.">
        <PartnerNote />
        <div className="cta-row">
          <WhatsAppButton category="umrah">Konsultasi Program Umrah</WhatsAppButton>
          <LinkButton href={SITE.kebaikanTour} external>Kebaikan Tour</LinkButton>
        </div>
      </PageHead>
      <section className="blk">
        <div className="wrap">
          <h2>Jadwal keberangkatan</h2>
          <div className="scroll">
            <table>
              <thead><tr><th>Program</th><th>Bulan</th><th>Keterangan</th></tr></thead>
              <tbody>{JADWAL.map((j, i) => <tr key={i}><td>{j.program}</td><td>{j.bulan}</td><td>{j.keterangan}</td></tr>)}</tbody>
            </table>
          </div>
        </div>
      </section>
      <section className="blk">
        <div className="wrap"><h2>Pengalaman umrah</h2><Gallery photos={UMRAH} /></div>
      </section>
      <section className="blk alt" id="tips">
        <div className="wrap">
          <h2>Tips persiapan &amp; menabung untuk umrah</h2>
          <div className="grid g3" style={{ marginTop: 20 }}>
            <Link className="card acard" href="/artikel/tips-persiapan-umrah">
              <h3>15 Tips Persiapan Ibadah Umrah</h3>
              <p>Niat, memilih travel, dokumen, perlengkapan, dan kesehatan.</p>
              <span className="more">Baca artikel →</span>
            </Link>
            <div className="card acard">
              <h3>Tips menabung untuk umrah</h3>
              <p>Informasi program tabungan emas menuju Baitullah di situs Mantauin Emas. Syarat dan ketentuan mengikuti situs tersebut, konfirmasikan ke admin sebelum mulai menabung.</p>
              <LinkButton href={SITE.mantauin} external small>Buka situs Mantauin Emas</LinkButton>
            </div>
            <div className="card acard">
              <h3>Edukasi perjalanan</h3>
              <p>Informasi program Kebaikan Tour untuk perjalanan ke Tanah Suci.</p>
              <LinkButton href={SITE.kebaikanTour} external small>iman.kebaikantour.com</LinkButton>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

import type { MetadataRoute } from 'next';
import { SITE } from '@/lib/site';
import { ARTICLES } from '@/data/articles';

export default function sitemap(): MetadataRoute.Sitemap {
  const pages = ['', '/ekspedisi', '/umrah-haji', '/kuliner', '/tentang-kami', '/artikel', '/kontak'];
  return [
    ...pages.map((p) => ({ url: `${SITE.url}${p}` })),
    ...ARTICLES.map((a) => ({ url: `${SITE.url}/artikel/${a.slug}` })),
  ];
}

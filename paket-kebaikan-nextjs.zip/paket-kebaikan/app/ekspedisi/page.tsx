import type { Metadata } from 'next';
import PageHead from '@/components/PageHead';
import WhatsAppButton from '@/components/WhatsAppButton';
import LinkButton from '@/components/LinkButton';
import Gallery from '@/components/Gallery';
import Steps from '@/components/Steps';
import JsonLd from '@/components/JsonLd';
import { PENGIRIMAN } from '@/data/gallery';

export const metadata: Metadata = {
  title: 'Jasa Pengiriman Barang & Motor ke Seluruh Indonesia',
  description: 'Kirim dokumen, paket, pakaian, makanan, barang elektronik, pindahan rumah, hingga sepeda motor ke berbagai wilayah Indonesia bersama Paket Kebaikan.',
  alternates: { canonical: '/ekspedisi' },
};

const JENIS: [string, string][] = [
  ['📄 Dokumen & paket', 'Berkas penting dan paket harian.'],
  ['👕 Pakaian & aksesori', 'Barang jualan maupun kiriman pribadi.'],
  ['🍲 Makanan', 'Oleh-oleh dan makanan kiriman.'],
  ['💻 Barang elektronik', 'Pindahan perangkat elektronik.'],
  ['🏠 Pindahan rumah', 'Barang pindahan antar kota.'],
  ['🏍️ Sepeda motor', 'Pengiriman motor ke berbagai wilayah.'],
];

const FAQ: [string, string][] = [
  ['Apakah bisa kirim motor ke luar pulau?', 'Tanyakan tujuan Anda lewat WhatsApp, kami informasikan opsi yang tersedia.'],
  ['Bagaimana mengetahui biaya kirim?', 'Biaya bergantung pada jenis barang, ukuran, dan tujuan. Kirim detailnya via WhatsApp.'],
];

export default function EkspedisiPage() {
  return (
    <>
      <JsonLd data={{ '@context': 'https://schema.org', '@type': 'Service', name: 'Jasa pengiriman barang dan motor', areaServed: 'ID', provider: { '@type': 'LocalBusiness', name: 'Paket Kebaikan' } }} />
      <PageHead crumb="Ekspedisi" title="Jasa pengiriman barang ke seluruh Indonesia" lead="Dari dokumen sampai sepeda motor. Ceritakan barang dan tujuan Anda, kami bantu informasikan opsi pengirimannya.">
        <div className="cta-row">
          <WhatsAppButton category="ekspedisi">Tanya Ongkir via WhatsApp</WhatsAppButton>
          <LinkButton href="/#alur">Lihat kemudahan pesan</LinkButton>
        </div>
      </PageHead>
      <section className="blk">
        <div className="wrap">
          <h2>Yang bisa kami kirim</h2>
          <div className="grid g3" style={{ marginTop: 20 }}>
            {JENIS.map(([t, d]) => <div className="card" key={t}><h3>{t}</h3><p style={{ color: 'var(--muted)', margin: 0 }}>{d}</p></div>)}
          </div>
        </div>
      </section>
      <section className="blk">
        <div className="wrap"><h2>Dokumentasi pengiriman</h2><Gallery photos={PENGIRIMAN} /></div>
      </section>
      <section className="blk alt">
        <div className="wrap">
          <h2>Cara kirim</h2>
          <Steps items={[['Kirim detail', 'Jenis barang, asal, tujuan.'], ['Dapat informasi', 'Biaya dan estimasi dijelaskan.'], ['Setuju', 'Konfirmasi pengiriman.'], ['Barang dikirim', 'Kami proses sesuai kesepakatan.']]} />
          <h2 style={{ marginTop: 44 }}>Pertanyaan umum</h2>
          {FAQ.map(([q, a]) => <details key={q}><summary>{q}</summary><p>{a}</p></details>)}
        </div>
      </section>
    </>
  );
}

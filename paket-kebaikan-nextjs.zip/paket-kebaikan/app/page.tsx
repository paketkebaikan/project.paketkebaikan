import type { Metadata } from 'next';
import Image from 'next/image';
import { Handshake, Truck, Eye, Sprout, Package, Moon, Utensils, type LucideIcon } from 'lucide-react';
import LinkButton from '@/components/LinkButton';
import WhatsAppButton from '@/components/WhatsAppButton';
import DocTabs from '@/components/DocTabs';
import ArticleCard from '@/components/ArticleCard';
import Steps from '@/components/Steps';
import Testimonials from '@/components/Testimonials';
import { ARTICLES } from '@/data/articles';
import type { WaCategory } from '@/lib/whatsapp';

export const metadata: Metadata = { alternates: { canonical: '/' } };

const KEUNGGULAN: { icon: LucideIcon; title: string; text: string }[] = [
  { icon: Handshake, title: 'Komunikasi langsung', text: 'Tanya dan konfirmasi lewat WhatsApp.' },
  { icon: Truck, title: 'Jangkauan luas', text: 'Pengiriman ke berbagai wilayah Indonesia.' },
  { icon: Eye, title: 'Informasi transparan', text: 'Peran kami dijelaskan jelas di tiap layanan.' },
  { icon: Sprout, title: 'Mendukung UMKM', text: 'Kuliner dari pelaku usaha rumahan.' },
];

const PILAR: { icon: LucideIcon; title: string; href: string; cat: WaCategory; text: string; cta: string }[] = [
  { icon: Package, title: 'Ekspedisi', href: '/ekspedisi', cat: 'ekspedisi', cta: 'Tanya via WA',
    text: 'Dokumen, paket, pakaian, makanan, aksesori, barang elektronik, pindahan rumah, hingga sepeda motor.' },
  { icon: Moon, title: 'Umrah & Haji', href: '/umrah-haji', cat: 'umrah', cta: 'Tanya via WA',
    text: 'Informasi program, jadwal, persiapan ibadah, dan tips menabung. Kami mitra pemasaran Kebaikan Tour.' },
  { icon: Utensils, title: 'Kuliner', href: '/kuliner', cat: 'kuliner', cta: 'Pesan via WA',
    text: 'Makanan rumahan dari UMKM dan ibu rumah tangga dengan sistem open order.' },
];

export default function HomePage() {
  return (
    <>
      <section className="hero">
        <div className="wrap">
          <div>
            <span className="pill">Melayani sejak 2016</span>
            <h1>Dari sebuah niat menyampaikan aneka kebaikan</h1>
            <p className="lead">Satu lokasi, berbagai layanan: Pengiriman Barang, Produk Kuliner UMKM, dan niat menyampaikan amanat muslim menuju Baitullah.</p>
            <div className="cta-row">
              <WhatsAppButton category="umum">Hubungi Admin</WhatsAppButton>
              <LinkButton href="/#alur">Lihat kemudahan pesan</LinkButton>
            </div>
          </div>
          <div className="logo-stage">
            <Image src="/logo.jpg" alt="Logo Paket Kebaikan: paket berhias hati" width={480} height={441} priority />
          </div>
        </div>
      </section>

      <section className="blk alt">
        <div className="wrap">
          <h2>Dari antar dokumen jadi tiga layanan</h2>
          <p>Paket Kebaikan dimulai tahun 2016 dari pengiriman dokumen, pakaian, makanan, dan barang pindahan. Seiring waktu, layanan tumbuh menjadi tiga bidang yang saling melengkapi.</p>
        </div>
      </section>

      <section className="blk">
        <div className="wrap">
          <h2>Kenapa memilih Paket Kebaikan</h2>
          <div className="grid g4" style={{ marginTop: 20 }}>
            {KEUNGGULAN.map(({ icon: Icon, title, text }) => (
              <div className="feat" key={title}>
                <div><Icon size={22} color="var(--orange-d)" aria-hidden="true" /></div>
                <div><b>{title}</b><span>{text}</span></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="blk alt" id="pilar">
        <div className="wrap">
          <h2>Tiga pilar layanan</h2>
          <div className="grid g3" style={{ marginTop: 20 }}>
            {PILAR.map(({ icon: Icon, title, href, cat, text, cta }) => (
              <article className="card pillar" key={title}>
                <div className="ic"><Icon size={26} color="var(--orange-d)" aria-hidden="true" /></div>
                <h3>{title}</h3>
                <p>{text}</p>
                <div className="acts">
                  <LinkButton href={href} small>Selengkapnya</LinkButton>
                  <WhatsAppButton category={cat} small>{cta}</WhatsAppButton>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="blk">
        <div className="wrap">
          <h2>Dokumentasi kegiatan</h2>
          <DocTabs />
        </div>
      </section>

      <section className="blk alt" id="alur">
        <div className="wrap">
          <h2>Alur pemesanan</h2>
          <Steps items={[['Hubungi kami', 'Klik tombol WhatsApp sesuai layanan.'], ['Konsultasi', 'Ceritakan kebutuhan Anda.'], ['Konfirmasi', 'Detail layanan disepakati bersama.'], ['Diproses', 'Kami tindak lanjuti sesuai kesepakatan.']]} />
        </div>
      </section>

      <section className="blk">
        <div className="wrap">
          <h2>Testimoni pelanggan</h2>
          <Testimonials />
        </div>
      </section>

      <section className="blk alt">
        <div className="wrap">
          <h2>Artikel &amp; informasi</h2>
          <div className="grid g3" style={{ marginTop: 20 }}>
            {ARTICLES.map((a) => <ArticleCard key={a.slug} article={a} />)}
          </div>
          <p style={{ marginTop: 22 }}><LinkButton href="/artikel" small>Lihat semua artikel</LinkButton></p>
        </div>
      </section>
    </>
  );
}

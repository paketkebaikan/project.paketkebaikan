import type { Metadata } from 'next';
import PageHead from '@/components/PageHead';
import ArticleCard from '@/components/ArticleCard';
import { ARTICLES } from '@/data/articles';

export const metadata: Metadata = {
  title: 'Artikel & Informasi',
  description: 'Tips seputar pengiriman barang, persiapan umrah, dan cara pesan kuliner UMKM.',
  alternates: { canonical: '/artikel' },
};

export default function ArtikelPage() {
  return (
    <>
      <PageHead crumb="Artikel" title="Artikel & informasi" lead="Tips seputar pengiriman, persiapan umrah, dan pesan kuliner UMKM." />
      <section className="blk" style={{ paddingTop: 8 }}>
        <div className="wrap grid g3">{ARTICLES.map((a) => <ArticleCard key={a.slug} article={a} />)}</div>
      </section>
    </>
  );
}

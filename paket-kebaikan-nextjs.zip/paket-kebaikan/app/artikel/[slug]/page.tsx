import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import PageHead from '@/components/PageHead';
import WhatsAppButton from '@/components/WhatsAppButton';
import LinkButton from '@/components/LinkButton';
import PartnerNote from '@/components/PartnerNote';
import JsonLd from '@/components/JsonLd';
import { ARTICLES } from '@/data/articles';
import { getArticleHtml } from '@/lib/articles';

type Props = { params: { slug: string } };

export function generateStaticParams() {
  return ARTICLES.map((a) => ({ slug: a.slug }));
}

export function generateMetadata({ params }: Props): Metadata {
  const a = ARTICLES.find((x) => x.slug === params.slug);
  if (!a) return {};
  return { title: a.title, description: a.excerpt, alternates: { canonical: `/artikel/${a.slug}` } };
}

export default function ArtikelDetailPage({ params }: Props) {
  const a = ARTICLES.find((x) => x.slug === params.slug);
  if (!a) notFound();
  const html = getArticleHtml(a.slug);
  return (
    <>
      <JsonLd data={{ '@context': 'https://schema.org', '@type': 'Article', headline: a.title, description: a.excerpt, author: { '@type': 'Organization', name: 'Paket Kebaikan' } }} />
      <div className="wrap hdr-sub">
        <div className="crumb"><Link href="/">Beranda</Link> / <Link href="/artikel">Artikel</Link> / {a.category}</div>
        <h1 style={{ fontSize: 'clamp(1.7rem,5vw,2.5rem)' }}>{a.title}</h1>
      </div>
      <article className="wrap prose" style={{ paddingBottom: 24 }} dangerouslySetInnerHTML={{ __html: html }} />
      <div className="wrap prose" style={{ paddingBottom: 40 }}>
        {a.partnerNote && <PartnerNote />}
        <div className="cta-row">
          <WhatsAppButton category={a.cat}>Hubungi Admin</WhatsAppButton>
          <LinkButton href="/artikel">Artikel lainnya</LinkButton>
        </div>
      </div>
    </>
  );
}

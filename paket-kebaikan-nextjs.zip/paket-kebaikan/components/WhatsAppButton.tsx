import type { ReactNode } from 'react';
import { MessageCircle } from 'lucide-react';
import { waLink, type WaCategory } from '@/lib/whatsapp';

type Props = { category: WaCategory; detail?: string; small?: boolean; children?: ReactNode };

export default function WhatsAppButton({ category, detail, small, children }: Props) {
  return (
    <a className={`btn btn-wa${small ? ' sm' : ''}`} href={waLink(category, detail)} target="_blank" rel="noopener noreferrer">
      <MessageCircle size={18} aria-hidden="true" /> {children ?? 'Hubungi Admin'}
    </a>
  );
}

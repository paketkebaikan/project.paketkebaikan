'use client';
import { useState } from 'react';
import { PENGIRIMAN, UMRAH, type Photo } from '@/data/gallery';
import { MENU } from '@/data/menu';

const TABS: { id: string; label: string; photos: Photo[] }[] = [
  { id: 'pengiriman', label: 'Pengiriman', photos: PENGIRIMAN.slice(0, 3) },
  { id: 'umrah', label: 'Pengalaman umrah', photos: UMRAH.slice(0, 3) },
  { id: 'kuliner', label: 'Produk kuliner', photos: MENU.slice(0, 3).map((m) => ({ src: m.img, cap: m.name, alt: m.name })) },
];

export default function DocTabs() {
  const [active, setActive] = useState('pengiriman');
  const current = TABS.find((t) => t.id === active) ?? TABS[0];
  return (
    <>
      <div className="tabs" role="tablist">
        {TABS.map((t) => (
          <button key={t.id} role="tab" aria-selected={t.id === active} onClick={() => setActive(t.id)}>{t.label}</button>
        ))}
      </div>
      <div className="grid g3">
        {current.photos.map((p) => (
          <figure className="fig" key={p.src}>
            <img src={p.src} alt={p.alt} loading="lazy" />
            <figcaption>{p.cap}</figcaption>
          </figure>
        ))}
      </div>
    </>
  );
}

'use client';
import { useRef, useState } from 'react';
import { Music, Pause } from 'lucide-react';

export default function MusicPlayer() {
  const ref = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const toggle = async () => {
    const a = ref.current;
    if (!a) return;
    if (a.paused) {
      try { await a.play(); setPlaying(true); } catch { setPlaying(false); }
    } else {
      a.pause();
      setPlaying(false);
    }
  };
  return (
    <>
      <audio ref={ref} src="/audio/bgm.mp3" loop preload="none" />
      <button className="music" onClick={toggle} aria-pressed={playing} title="Satu Langkah Banyak Kebaikan">
        {playing ? <Pause size={16} /> : <Music size={16} />} <span>{playing ? 'Jeda musik' : 'Putar musik'}</span>
      </button>
    </>
  );
}

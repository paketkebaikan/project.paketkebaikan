'use client';
import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, X } from 'lucide-react';
import { NAV } from '@/lib/site';
import { waLink } from '@/lib/whatsapp';

export default function Header() {
  const path = usePathname() || '/';
  const [open, setOpen] = useState(false);
  const isActive = (href: string) => (href === '/' ? path === '/' : path.startsWith(href));
  return (
    <header>
      <div className="wrap">
        <div className="bar">
          <Link className="brand" href="/" aria-label="Paket Kebaikan, ke beranda">
            <i role="img" aria-label="Logo Paket Kebaikan" />Paket Kebaikan
          </Link>
          <nav aria-label="Menu utama">
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} aria-current={isActive(n.href) ? 'page' : undefined}>{n.label}</Link>
            ))}
          </nav>
          <a className="btn btn-wa sm hdrwa" href={waLink('umum')} target="_blank" rel="noopener noreferrer">Chat WhatsApp</a>
          <button className="menubtn" aria-label={open ? 'Tutup menu' : 'Buka menu'} aria-expanded={open} onClick={() => setOpen(!open)}>
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>
      <div id="drawer" className={open ? 'open' : ''}>
        {NAV.map((n) => (
          <Link key={n.href} href={n.href} onClick={() => setOpen(false)}>{n.label}</Link>
        ))}
      </div>
    </header>
  );
}

export default function PartnerNote() {
  return (
    <div className="note">
      <b>Transparansi:</b> Paket Kebaikan adalah <b>mitra pemasaran Kebaikan Tour</b>. Kami bukan penyelenggara perjalanan ibadah.
      Penyelenggaraan dan perizinan berada pada pihak penyelenggara resmi.
    </div>
  );
}

import type { Photo } from '@/data/gallery';

export default function Gallery({ photos }: { photos: Photo[] }) {
  return (
    <div className="grid g4">
      {photos.map((p) => (
        <figure className="fig" key={p.src}>
          <img src={p.src} alt={p.alt} loading="lazy" />
          <figcaption>{p.cap}</figcaption>
        </figure>
      ))}
    </div>
  );
}

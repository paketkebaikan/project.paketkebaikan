'use client';
import { useState } from 'react';
import { waLink, type WaCategory } from '@/lib/whatsapp';

export default function ContactForm() {
  const [nama, setNama] = useState('');
  const [layanan, setLayanan] = useState<WaCategory>('ekspedisi');
  const [pesan, setPesan] = useState('');
  const href = waLink(layanan, `Nama saya ${nama || '(nama)'}. ${pesan}`.trim());
  return (
    <div className="card">
      <label htmlFor="fn">Nama</label>
      <input id="fn" autoComplete="name" value={nama} onChange={(e) => setNama(e.target.value)} />
      <label htmlFor="fl">Layanan</label>
      <select id="fl" value={layanan} onChange={(e) => setLayanan(e.target.value as WaCategory)}>
        <option value="ekspedisi">Ekspedisi (Kang Iman)</option>
        <option value="umrah">Umrah &amp; Haji (Kang Iman)</option>
        <option value="kuliner">Kuliner (Teh Risma)</option>
      </select>
      <label htmlFor="fm">Pesan</label>
      <textarea id="fm" rows={4} value={pesan} onChange={(e) => setPesan(e.target.value)} />
      <a className="btn btn-wa" href={href} target="_blank" rel="noopener noreferrer">Kirim via WhatsApp</a>
    </div>
  );
}

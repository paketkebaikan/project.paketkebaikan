import type { ReactNode } from 'react';
import Link from 'next/link';

type Props = { href: string; variant?: 'gold' | 'line'; small?: boolean; external?: boolean; children: ReactNode };

export default function LinkButton({ href, variant = 'gold', small, external, children }: Props) {
  const cls = `btn btn-${variant}${small ? ' sm' : ''}`;
  if (external) return <a className={cls} href={href} target="_blank" rel="noopener noreferrer">{children}</a>;
  return <Link className={cls} href={href}>{children}</Link>;
}

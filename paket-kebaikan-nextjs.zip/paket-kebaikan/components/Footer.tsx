import Link from 'next/link';
import { SITE, NAV } from '@/lib/site';

export default function Footer() {
  return (
    <footer>
      <div className="wrap cols">
        <div>
          <b style={{ fontFamily: 'Poppins, sans-serif', color: 'var(--ink)' }}>Paket Kebaikan</b>
          <p style={{ marginTop: 8 }}>Ekspedisi, informasi umrah dan haji, dan kuliner UMKM sejak 2016.</p>
          <p>Paket Kebaikan adalah mitra pemasaran Kebaikan Tour dan bukan penyelenggara perjalanan ibadah.</p>
        </div>
        <div>
          {NAV.slice(1).map((n) => <Link key={n.href} href={n.href}>{n.label}</Link>)}
          <Link href="/tentang-kami">Tentang Kami</Link>
          <a href={SITE.kebaikanTour} target="_blank" rel="noopener noreferrer">iman.kebaikantour.com</a>
        </div>
        <div>
          Kantor: {SITE.address}
          <br /><br />WhatsApp<br />
          {SITE.kangIman.display} ({SITE.kangIman.label})<br />
          {SITE.tehRisma.display} ({SITE.tehRisma.label})<br />
          www.paketkebaikan.my.id
        </div>
      </div>
    </footer>
  );
}

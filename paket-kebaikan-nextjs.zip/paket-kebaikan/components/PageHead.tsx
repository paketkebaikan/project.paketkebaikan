import type { ReactNode } from 'react';
import Link from 'next/link';

type Props = { crumb: string; title: string; lead?: string; children?: ReactNode };

export default function PageHead({ crumb, title, lead, children }: Props) {
  return (
    <div className="wrap hdr-sub">
      <div className="crumb"><Link href="/">Beranda</Link> / {crumb}</div>
      <h1>{title}</h1>
      {lead && <p className="lead" style={{ color: 'var(--muted)' }}>{lead}</p>}
      {children}
    </div>
  );
}

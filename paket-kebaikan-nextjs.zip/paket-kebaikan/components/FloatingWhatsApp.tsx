import { MessageCircle } from 'lucide-react';
import { waLink } from '@/lib/whatsapp';

export default function FloatingWhatsApp() {
  return (
    <a className="float" href={waLink('umum')} target="_blank" rel="noopener noreferrer" aria-label="Chat WhatsApp">
      <MessageCircle size={28} color="#2A1606" aria-hidden="true" />
    </a>
  );
}

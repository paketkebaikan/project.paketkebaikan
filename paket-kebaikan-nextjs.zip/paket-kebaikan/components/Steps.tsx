export default function Steps({ items }: { items: [string, string][] }) {
  return (
    <ol className="steps" style={{ marginTop: 20 }}>
      {items.map(([title, text]) => (
        <li key={title}><b>{title}</b><br />{text}</li>
      ))}
    </ol>
  );
}

import Link from 'next/link';
import type { Article } from '@/data/articles';

export default function ArticleCard({ article }: { article: Article }) {
  return (
    <Link className="card acard" href={`/artikel/${article.slug}`}>
      <div className="pill" style={{ alignSelf: 'flex-start' }}>{article.tag}</div>
      <h3>{article.title}</h3>
      <p>{article.excerpt}</p>
      <span className="more">Baca artikel →</span>
    </Link>
  );
}

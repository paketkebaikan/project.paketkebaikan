import { TESTIMONI, ILUSTRASI } from '@/data/testimoni';

export default function Testimonials() {
  return (
    <>
      <div className="grid g2">
        {TESTIMONI.map((t) => (
          <figure className="fig tm" key={t.src}>
            <img src={t.src} alt={t.alt} loading="lazy" />
            <figcaption>{t.cap}</figcaption>
          </figure>
        ))}
      </div>
      {ILUSTRASI && (
        <p className="tmnote">Gambar di atas adalah ilustrasi contoh tampilan testimoni, bukan ulasan pelanggan sebenarnya. Testimoni asli akan menggantikannya setelah dokumentasi dan izin pelanggan tersedia.</p>
      )}
    </>
  );
}

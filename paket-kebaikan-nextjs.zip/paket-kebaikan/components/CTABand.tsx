import LinkButton from './LinkButton';
import WhatsAppButton from './WhatsAppButton';

export default function CTABand() {
  return (
    <div className="wrap" style={{ marginBottom: 56 }}>
      <div className="cta-band">
        <div>
          <h2 style={{ margin: '0 0 8px' }}>Siap dibantu?</h2>
          <p style={{ margin: 0 }}>Ceritakan kebutuhan Anda, kami balas lewat WhatsApp.</p>
        </div>
        <div className="cta-row" style={{ margin: 0 }}>
          <LinkButton href="/#alur">Lihat kemudahan pesan</LinkButton>
          <WhatsAppButton category="umum">Hubungi Admin</WhatsAppButton>
        </div>
      </div>
    </div>
  );
}

import type { WaCategory } from '@/lib/whatsapp';

export type Article = { slug: string; title: string; category: string; tag: string; excerpt: string; cat: WaCategory; partnerNote?: boolean };

export const ARTICLES: Article[] = [
  { slug: 'tips-pengiriman-barang-aman', category: 'Pengiriman', tag: 'Tips Pengiriman', cat: 'ekspedisi',
    title: '10 Tips Pengiriman Barang yang Aman dan Nyaman, Agar Paket Sampai Tujuan Tanpa Khawatir',
    excerpt: 'Kemasan, alamat, pilihan ekspedisi, hingga resi: 10 hal yang perlu disiapkan sebelum mengirim barang.' },
  { slug: 'tips-persiapan-umrah', category: 'Umrah & Haji', tag: 'Tips Umrah', cat: 'umrah', partnerNote: true,
    title: '15 Tips Persiapan Ibadah Umrah agar Perjalanan Lancar, Nyaman, dan Penuh Berkah',
    excerpt: 'Dari niat, memilih travel, dokumen, hingga perlengkapan: 15 tips sebelum berangkat ke Tanah Suci.' },
  { slug: 'cara-pesan-kuliner-umkm', category: 'Kuliner', tag: 'Kuliner UMKM', cat: 'kuliner',
    title: 'Cara Praktis Pesan Produk Kuliner di Paket Kebaikan, Banyak Pilihan Menu Tinggal Pesan!',
    excerpt: 'Lima langkah mudah memesan menu dari UMKM dan ibu rumah tangga lewat WhatsApp.' },
];

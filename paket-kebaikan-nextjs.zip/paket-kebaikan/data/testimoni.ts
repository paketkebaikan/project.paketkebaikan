export type Testimoni = { src: string; alt: string; cap: string };

// Gambar saat ini adalah ILUSTRASI contoh. Setelah ada testimoni pelanggan asli (dengan izin),
// ganti file di public/images dan ubah ILUSTRASI menjadi false.
export const ILUSTRASI = true;

export const TESTIMONI: Testimoni[] = [
  { src: '/images/testimoni-pengiriman.jpg', alt: 'Contoh tampilan testimoni jasa pengiriman barang (ilustrasi)', cap: 'Pengiriman barang' },
  { src: '/images/testimoni-kuliner.jpg', alt: 'Contoh tampilan testimoni jasa pesan produk kuliner (ilustrasi)', cap: 'Produk kuliner' },
];

export type MenuItem = { slug: string; name: string; desc: string; img: string };
const DEFAULT = 'Open order. Tanyakan harga dan jadwal via WhatsApp.';

export const MENU: MenuItem[] = [
  { slug: 'paket-nasi-ayam', name: 'Paket Nasi Ayam', desc: DEFAULT, img: '/images/menu-paket-nasi-ayam.jpg' },
  { slug: 'nasi-tutug-tempe-ayam', name: 'Nasi Tutug Tempe Ayam', desc: DEFAULT, img: '/images/menu-nasi-tutug-tempe-ayam.jpg' },
  { slug: 'fudgy-brownies', name: 'Fudgy Brownies', desc: DEFAULT, img: '/images/menu-fudgy-brownies.jpg' },
  { slug: 'mini-fudgy-brownies', name: 'Mini Fudgy Brownies', desc: DEFAULT, img: '/images/menu-mini-fudgy-brownies.jpg' },
  { slug: 'burnt-cheese-toast', name: 'Burnt Cheese Toast', desc: DEFAULT, img: '/images/menu-burnt-cheese-toast.jpg' },
  { slug: 'bolen-pisang', name: 'Bolen Pisang', desc: DEFAULT, img: '/images/menu-bolen-pisang.jpg' },
  { slug: 'roti-kopi', name: 'Roti Kopi', desc: DEFAULT, img: '/images/menu-roti-kopi.jpg' },
  { slug: 'oatmeal-cookies', name: 'Oatmeal Cookies', desc: DEFAULT, img: '/images/menu-oatmeal-cookies.jpg' },
  { slug: 'baso-tahu-imut', name: 'Baso Tahu Imut', desc: 'Pengantaran setiap hari mulai pagi, area Cimahi dan Bandung.', img: '/images/menu-baso-tahu-imut.jpg' },
];

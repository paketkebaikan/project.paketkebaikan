// Edit file ini untuk memperbarui jadwal. Data diisi dari pihak penyelenggara.
export type Jadwal = { program: string; bulan: string; keterangan: string };
export const JADWAL: Jadwal[] = [
  { program: 'Contoh program', bulan: 'Akan diperbarui', keterangan: 'Hubungi WhatsApp untuk jadwal terbaru' },
  { program: 'Contoh program', bulan: 'Akan diperbarui', keterangan: 'Data diisi dari pihak Kebaikan Tour' },
];

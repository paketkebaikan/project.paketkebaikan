export type Photo = { src: string; cap: string; alt: string };

export const PENGIRIMAN: Photo[] = [
  { src: '/images/pengiriman-1.jpg', cap: 'Proses sortir dan packing paket', alt: 'Dua petugas menyortir paket di dalam keranjang' },
  { src: '/images/pengiriman-2.jpg', cap: 'Lokasi kantor di Jl. Boeing Raya, Cimahi', alt: 'Tampak depan kantor dengan spanduk layanan pengiriman' },
  { src: '/images/pengiriman-3.jpg', cap: 'Poster layanan Paket Kebaikan di kantor', alt: 'Poster Paket Kebaikan terpasang di pintu kantor' },
  { src: '/images/pengiriman-4.jpg', cap: 'Area layanan dan papan informasi', alt: 'Pintu area layanan dengan papan pengumuman' },
];

export const UMRAH: Photo[] = [
  { src: '/images/umrah-1.jpg', cap: 'Suasana di Masjidil Haram, Makkah', alt: 'Dua jamaah berfoto di pelataran Masjidil Haram dengan Ka’bah di belakang pada malam hari' },
  { src: '/images/umrah-2.jpg', cap: 'Perjalanan ibadah di Makkah', alt: 'Dua jamaah berfoto di depan bangunan di kawasan Masjidil Haram' },
  { src: '/images/umrah-3.jpg', cap: 'Pelataran Masjid Nabawi, Madinah', alt: 'Rombongan jamaah berfoto di pelataran Masjid Nabawi' },
  { src: '/images/umrah-4.jpg', cap: 'Kawasan sekitar Masjidil Haram', alt: 'Jamaah berdiri di jalan kawasan hotel dekat Masjidil Haram' },
];

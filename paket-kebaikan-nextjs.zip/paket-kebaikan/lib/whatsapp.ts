import { SITE } from './site';

export type WaCategory = 'umum' | 'ekspedisi' | 'umrah' | 'kuliner';

const MESSAGES: Record<WaCategory, string> = {
  umum: 'Halo Paket Kebaikan, saya ingin bertanya tentang layanan Anda.',
  ekspedisi: 'Halo Paket Kebaikan, saya ingin tanya pengiriman barang. Jenis barang: ... Dari: ... Ke: ...',
  umrah: 'Halo Paket Kebaikan, saya ingin informasi program umrah/haji dari Kebaikan Tour.',
  kuliner: 'Halo Paket Kebaikan, saya ingin pesan makanan open order.',
};

// Kang Iman: pengiriman dan umrah. Teh Risma: kuliner.
const NUMBERS: Record<WaCategory, string> = {
  umum: SITE.kangIman.number,
  ekspedisi: SITE.kangIman.number,
  umrah: SITE.kangIman.number,
  kuliner: SITE.tehRisma.number,
};

export function waLink(category: WaCategory, detail?: string): string {
  const text = detail ? `${MESSAGES[category]} ${detail}` : MESSAGES[category];
  return `https://wa.me/${NUMBERS[category]}?text=${encodeURIComponent(text)}`;
}

export const SITE = {
  name: 'Paket Kebaikan',
  url: 'https://www.paketkebaikan.my.id',
  description: 'Satu lokasi, berbagai layanan: pengiriman barang dan motor ke seluruh Indonesia, produk kuliner UMKM, dan informasi umrah dan haji.',
  kangIman: { label: 'Kang Iman', number: '6282215333048', display: '0822-1533-3048', role: 'Pengiriman barang dan pendaftaran umrah' },
  tehRisma: { label: 'Teh Risma', number: '6289683922648', display: '0896-8392-2648', role: 'Produk kuliner' },
  address: 'Melong Green Garden, Jl. Boeing Raya No. 30-32 RT 02 RW 28, Kel. Melong, Kec. Cimahi Selatan, Cimahi, Jawa Barat 40534',
  maps: 'https://www.google.com/maps/search/?api=1&query=Melong+Green+Garden+Jl.+Boeing+Raya+30-32+Cimahi',
  kebaikanTour: 'https://iman.kebaikantour.com',
  mantauin: 'https://sites.google.com/view/mantauinemas/jual-beli-emas?authuser=0',
};
export const NAV = [
  { href: '/', label: 'Beranda' },
  { href: '/ekspedisi', label: 'Ekspedisi' },
  { href: '/umrah-haji', label: 'Umrah & Haji' },
  { href: '/kuliner', label: 'Kuliner' },
  { href: '/artikel', label: 'Artikel' },
  { href: '/kontak', label: 'Kontak' },
];

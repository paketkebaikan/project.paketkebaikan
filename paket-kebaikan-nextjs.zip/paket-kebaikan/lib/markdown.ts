function inline(x: string): string {
  let r = x.replace(/&/g, '&amp;');
  r = r.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\*(.+?)\*/g, '<i>$1</i>');
  return r.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
}

export function markdownToHtml(md: string): string {
  const out: string[] = [];
  let list: string[] = [];
  const flush = () => {
    if (list.length) out.push('<ul>' + list.map((i) => '<li>' + inline(i) + '</li>').join('') + '</ul>');
    list = [];
  };
  for (const raw of md.trim().split('\n')) {
    const ln = raw.trim();
    if (ln.startsWith('- ')) { list.push(ln.slice(2)); continue; }
    flush();
    if (!ln || ln === '---') continue;
    if (ln.startsWith('### ')) out.push('<h3>' + inline(ln.slice(4)) + '</h3>');
    else if (ln.startsWith('## ')) out.push('<h2>' + inline(ln.slice(3)) + '</h2>');
    else out.push('<p>' + inline(ln) + '</p>');
  }
  flush();
  return out.join('');
}

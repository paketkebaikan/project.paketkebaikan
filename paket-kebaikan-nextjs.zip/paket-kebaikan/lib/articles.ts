import fs from 'fs';
import path from 'path';
import { markdownToHtml } from './markdown';

export function getArticleHtml(slug: string): string {
  const file = path.join(process.cwd(), 'content', 'artikel', `${slug}.md`);
  return markdownToHtml(fs.readFileSync(file, 'utf8'));
}
